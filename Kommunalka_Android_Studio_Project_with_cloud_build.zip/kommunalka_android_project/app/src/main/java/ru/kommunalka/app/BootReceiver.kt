package ru.kommunalka.app

import android.app.*
import android.content.*
import android.os.Build
import java.util.Calendar

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val cal = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH,25); set(Calendar.HOUR_OF_DAY,9); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); if(timeInMillis <= System.currentTimeMillis()) add(Calendar.MONTH,1) }
        val nextIntent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context,5501,nextIntent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try { if(Build.VERSION.SDK_INT>=23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pending) else alarm.set(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pending) } catch (_: Exception) {}
    }
}
