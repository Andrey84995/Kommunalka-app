package ru.kommunalka.app

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && manager.getNotificationChannel("meter_reminders") == null) {
            manager.createNotificationChannel(NotificationChannel("meter_reminders", "Напоминания о счётчиках", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val notification = NotificationCompat.Builder(context, "meter_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Пора передать показания")
            .setContentText("Запишите показания воды, газа и электроэнергии.")
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        manager.notify(5501, notification)
        // Schedule the next monthly reminder using the stored default (25th at 09:00).
        val cal = Calendar.getInstance().apply { add(Calendar.MONTH, 1); set(Calendar.DAY_OF_MONTH, 25); set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val nextIntent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, 5501, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try { if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending) else alarm.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending) } catch (_: Exception) {}
    }
}
